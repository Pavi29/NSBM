-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2018 at 11:47 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nsbm`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `courseid` varchar(10) NOT NULL,
  `coursename` varchar(50) NOT NULL,
  `facid` varchar(10) NOT NULL,
  `degree` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`courseid`, `coursename`, `facid`, `degree`) VALUES
('pb01', 'Business studies', 'b01', 'Master'),
('pc02', 'Computer Science', 'c02', 'Master'),
('pc11', 'Civil Engineering', 'e03', 'Master'),
('pe12', 'Electrical engineering', 'e03', 'Master'),
('ub12', ' Business studies', 'b01', 'Bachelor'),
('uc01', 'Computer Science', 'c02', 'Bachelor'),
('uc13', 'Civil Engineering', 'e03', 'Bachelor'),
('ue16', 'Electrical engineering', 'e03', 'Bachelor');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `facid` varchar(10) NOT NULL,
  `facname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`facid`, `facname`) VALUES
('b01', 'Faculty of Business'),
('c02', 'School of Computing'),
('e03', 'Faculty of Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `gpa`
--

CREATE TABLE `gpa` (
  `regno` int(10) NOT NULL,
  `courseid` varchar(10) NOT NULL,
  `gpa` double NOT NULL,
  `year` varchar(20) NOT NULL,
  `semester` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `instructor`
--

CREATE TABLE `instructor` (
  `iempid` varchar(20) NOT NULL,
  `iempname` varchar(100) NOT NULL,
  `nic` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contactno` int(10) NOT NULL,
  `roomno` varchar(10) NOT NULL,
  `facname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `instructor`
--

INSERT INTO `instructor` (`iempid`, `iempname`, `nic`, `email`, `address`, `contactno`, `roomno`, `facname`) VALUES
('i005', 'Asitha Costha', '912015242v', 'asi@gmail.com', '9,Gampaha', 778956423, 'i002', 'Faculty of Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `iteaches`
--

CREATE TABLE `iteaches` (
  `subcode` varchar(10) NOT NULL,
  `labno` varchar(10) NOT NULL,
  `iempid` varchar(10) NOT NULL,
  `facname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lab`
--

CREATE TABLE `lab` (
  `labno` varchar(10) NOT NULL,
  `sartingtime` varchar(20) NOT NULL,
  `endingtime` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lechall`
--

CREATE TABLE `lechall` (
  `lechallno` varchar(10) NOT NULL,
  `sartingtime` varchar(10) NOT NULL,
  `endingtime` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lecturehall`
--

CREATE TABLE `lecturehall` (
  `lechallno` varchar(10) NOT NULL,
  `startingtime` varchar(10) NOT NULL,
  `endingtime` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `lempid` varchar(20) NOT NULL,
  `lempname` varchar(100) NOT NULL,
  `nic` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contactno` int(10) NOT NULL,
  `roomno` varchar(10) NOT NULL,
  `facname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`lempid`, `lempname`, `nic`, `email`, `address`, `contactno`, `roomno`, `facname`) VALUES
('l003', 'Kamal Perera', '801245784v', 'kamalp@gmail.com', '9,Kandana', 764598543, 'l003', 'Faculty of Business'),
('l023', 'T.M.Dilshan', '704512685v', 'dilshan@gmail.com', '6,Dehiwala', 714526985, 'l012', 'School of Computing');

-- --------------------------------------------------------

--
-- Table structure for table `lteaches`
--

CREATE TABLE `lteaches` (
  `subcode` varchar(10) NOT NULL,
  `lechallno` varchar(10) NOT NULL,
  `lempid` varchar(10) NOT NULL,
  `facname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `psenrollsin`
--

CREATE TABLE `psenrollsin` (
  `regno` int(20) NOT NULL,
  `subcode` varchar(10) NOT NULL,
  `assignmentno` int(5) NOT NULL,
  `assignmentmark` double NOT NULL,
  `assignmentgrade` varchar(1) NOT NULL,
  `examgrade` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `psenrollsin`
--

INSERT INTO `psenrollsin` (`regno`, `subcode`, `assignmentno`, `assignmentmark`, `assignmentgrade`, `examgrade`) VALUES
(160008, '', 0, 0, '', 'B');

-- --------------------------------------------------------

--
-- Table structure for table `pstudent`
--

CREATE TABLE `pstudent` (
  `indexno` varchar(20) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `iname` varchar(100) NOT NULL,
  `regno` int(20) NOT NULL,
  `birthday` varchar(10) NOT NULL,
  `nic` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contactno` int(10) NOT NULL,
  `yearofcompletion` int(4) NOT NULL,
  `institute` varchar(50) NOT NULL,
  `qualificationtype` varchar(100) NOT NULL,
  `courseid` varchar(10) NOT NULL,
  `intake` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pstudent`
--

INSERT INTO `pstudent` (`indexno`, `fname`, `iname`, `regno`, `birthday`, `nic`, `email`, `address`, `contactno`, `yearofcompletion`, `institute`, `qualificationtype`, `courseid`, `intake`) VALUES
('2014/b23', 'Hashini Gayathri Jayasinghe', 'H.G.Jaysinghe', 140023, '1994/05/16', '945421586v', 'hashini@gmail.com', '2,temple road,kadawtha', 774521485, 2016, 'University of Colombo', 'BA', 'pb01', '16.1'),
('2014/e/87', 'Thilini Hendahewa', 'T.Hendahewa', 140087, '1996/09/18', '964578451v', 'thilini@gmail.com', '9/Jaela', 778451256, 2016, 'University of Moratuwa', 'Bsc', 'pe12', '16.1'),
('2016/cs/8', 'Hasini Amanda Wijewardena', 'H.A.Wijewardena', 160008, '1995/10/20', '954512965v', 'hasiniwije@gmail.com', 'No.6,lake road,Boralesgamuwa', 769874561, 2017, 'University of colombo school of computing', 'Bsc.Hons', 'pc02', '18.1'),
('2014/E/89', 'Dilki Gunawardena', 'D.Gunawardena', 160043, '1993/10/09', '934532987v', 'dilkig@gmail.com', 'No.9,temple road,pitakotte', 112345654, 2017, 'University of moratuwa', 'Bsc.Hons', 'pc11', '18.1'),
('2017/e/78', 'Amanda Bandara', 'A.Bandara', 170078, '1996/2/4', '964521365v', 'ama@gmail.com', '8,Maharagama', 778956421, 2019, 'NIBM', 'BSc', 'pc11', '17.1');

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `semno` int(1) NOT NULL,
  `year` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`semno`, `year`) VALUES
(1, 2017),
(1, 2018),
(2, 2017),
(2, 2018);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subcode` varchar(10) NOT NULL,
  `subname` varchar(50) NOT NULL,
  `subcost` int(5) NOT NULL,
  `noofassignments` int(5) NOT NULL,
  `numberofcredits` int(1) NOT NULL,
  `semno` int(1) NOT NULL,
  `facid` varchar(10) NOT NULL,
  `degree` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subcode`, `subname`, `subcost`, `noofassignments`, `numberofcredits`, `semno`, `facid`, `degree`) VALUES
('bs1101', 'Management Finance ', 3000, 3, 2, 1, 'b01', 'Bachelor'),
('ce1106', 'Hydraulics ', 4000, 4, 3, 2, 'e03', 'Master'),
('scs1101', 'Data structures and algorithms 1', 3000, 5, 3, 1, 'c02', 'Bachelor'),
('scs1102', 'Programming ', 3000, 4, 2, 1, 'c02', 'Bachelor'),
('scs1103', 'Database', 4000, 5, 3, 1, 'c02', 'Bachelor'),
('scs1104', 'Mathematical methods', 3000, 4, 2, 2, 'c02', 'Bachelor'),
('scs1105', 'Computer systems', 4000, 3, 2, 2, 'c02', 'Bachelor');

-- --------------------------------------------------------

--
-- Table structure for table `usenrollsin`
--

CREATE TABLE `usenrollsin` (
  `regno` int(20) NOT NULL,
  `subcode` varchar(10) NOT NULL,
  `assignmentno` int(5) NOT NULL,
  `assignmentmark` double NOT NULL,
  `assignmentgrade` varchar(2) NOT NULL,
  `examgrade` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usenrollsin`
--

INSERT INTO `usenrollsin` (`regno`, `subcode`, `assignmentno`, `assignmentmark`, `assignmentgrade`, `examgrade`) VALUES
(150003, 'scs1101', 3, 73, 'B+', '');

-- --------------------------------------------------------

--
-- Table structure for table `ustudent`
--

CREATE TABLE `ustudent` (
  `indexno` varchar(20) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `iname` varchar(100) NOT NULL,
  `regno` int(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `nic` varchar(10) NOT NULL,
  `birthday` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contactno` int(10) NOT NULL,
  `alindexno` int(10) NOT NULL,
  `alrank` int(10) NOT NULL,
  `alsub1` varchar(1) NOT NULL,
  `alsub2` varchar(1) NOT NULL,
  `alsub3` varchar(1) NOT NULL,
  `courseid` varchar(10) NOT NULL,
  `intake` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ustudent`
--

INSERT INTO `ustudent` (`indexno`, `fname`, `iname`, `regno`, `email`, `nic`, `birthday`, `address`, `contactno`, `alindexno`, `alrank`, `alsub1`, `alsub2`, `alsub3`, `courseid`, `intake`) VALUES
('2015/b/3', 'Dinithi Bhagya Jayasinghe', 'D.B.Jayasinghe', 150003, 'dinithij@gmail.com', '412584514v', '1997/07/27', 'NO.2,Sampath Uyana,Dewalapola', 711234567, 1452014521, 421, 'B', 'B', 'B', 'ub12', '18.1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`courseid`),
  ADD KEY `facid` (`facid`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`facid`);

--
-- Indexes for table `gpa`
--
ALTER TABLE `gpa`
  ADD PRIMARY KEY (`regno`),
  ADD KEY `courseid` (`courseid`);

--
-- Indexes for table `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`iempid`);

--
-- Indexes for table `iteaches`
--
ALTER TABLE `iteaches`
  ADD PRIMARY KEY (`subcode`,`labno`,`iempid`),
  ADD KEY `labno` (`labno`),
  ADD KEY `iempid` (`iempid`);

--
-- Indexes for table `lab`
--
ALTER TABLE `lab`
  ADD PRIMARY KEY (`labno`);

--
-- Indexes for table `lecturehall`
--
ALTER TABLE `lecturehall`
  ADD PRIMARY KEY (`lechallno`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`lempid`);

--
-- Indexes for table `lteaches`
--
ALTER TABLE `lteaches`
  ADD PRIMARY KEY (`subcode`,`lechallno`,`lempid`),
  ADD KEY `lempid` (`lempid`),
  ADD KEY `lechallno` (`lechallno`);

--
-- Indexes for table `psenrollsin`
--
ALTER TABLE `psenrollsin`
  ADD PRIMARY KEY (`regno`,`subcode`,`assignmentno`);

--
-- Indexes for table `pstudent`
--
ALTER TABLE `pstudent`
  ADD PRIMARY KEY (`regno`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`semno`,`year`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subcode`);

--
-- Indexes for table `usenrollsin`
--
ALTER TABLE `usenrollsin`
  ADD PRIMARY KEY (`regno`,`subcode`,`assignmentno`),
  ADD KEY `subcode` (`subcode`);

--
-- Indexes for table `ustudent`
--
ALTER TABLE `ustudent`
  ADD PRIMARY KEY (`regno`),
  ADD KEY `courseid` (`courseid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`facid`) REFERENCES `faculty` (`facid`);

--
-- Constraints for table `gpa`
--
ALTER TABLE `gpa`
  ADD CONSTRAINT `gpa_ibfk_1` FOREIGN KEY (`regno`) REFERENCES `ustudent` (`regno`),
  ADD CONSTRAINT `gpa_ibfk_2` FOREIGN KEY (`regno`) REFERENCES `pstudent` (`regno`),
  ADD CONSTRAINT `gpa_ibfk_3` FOREIGN KEY (`courseid`) REFERENCES `course` (`courseid`);

--
-- Constraints for table `iteaches`
--
ALTER TABLE `iteaches`
  ADD CONSTRAINT `iteaches_ibfk_1` FOREIGN KEY (`labno`) REFERENCES `lab` (`labno`),
  ADD CONSTRAINT `iteaches_ibfk_2` FOREIGN KEY (`iempid`) REFERENCES `instructor` (`iempid`),
  ADD CONSTRAINT `iteaches_ibfk_3` FOREIGN KEY (`subcode`) REFERENCES `subject` (`subcode`);

--
-- Constraints for table `lteaches`
--
ALTER TABLE `lteaches`
  ADD CONSTRAINT `lteaches_ibfk_1` FOREIGN KEY (`lempid`) REFERENCES `lecturer` (`lempid`),
  ADD CONSTRAINT `lteaches_ibfk_2` FOREIGN KEY (`subcode`) REFERENCES `subject` (`subcode`),
  ADD CONSTRAINT `lteaches_ibfk_3` FOREIGN KEY (`lechallno`) REFERENCES `lecturehall` (`lechallno`);

--
-- Constraints for table `psenrollsin`
--
ALTER TABLE `psenrollsin`
  ADD CONSTRAINT `psenrollsin_ibfk_1` FOREIGN KEY (`regno`) REFERENCES `pstudent` (`regno`);

--
-- Constraints for table `usenrollsin`
--
ALTER TABLE `usenrollsin`
  ADD CONSTRAINT `usenrollsin_ibfk_1` FOREIGN KEY (`regno`) REFERENCES `ustudent` (`regno`),
  ADD CONSTRAINT `usenrollsin_ibfk_2` FOREIGN KEY (`subcode`) REFERENCES `subject` (`subcode`);

--
-- Constraints for table `ustudent`
--
ALTER TABLE `ustudent`
  ADD CONSTRAINT `ustudent_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `course` (`courseid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
